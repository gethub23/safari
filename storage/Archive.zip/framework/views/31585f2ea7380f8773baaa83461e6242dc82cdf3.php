<?php $__env->startSection('title'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
        <?php $__currentLoopData = Home(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-xs-6">
                <div class="small-box smallBoxCustom" style="background-color: <?php echo e($h['color']); ?>">
                    <div class="inner">
                        <h3><?php echo e($h['count']); ?></h3>
                        <p style="color: white;"> <?php echo e($h['name']); ?> </p>
                    </div>
                    <div class="icon">
                            <?php echo $h['icon']; ?>

                    </div>
                    <a href="<?php echo e(url($h['url'])); ?>" class="small-box-footer"> الذهاب <i class="fa fa-arrow-circle-left"></i></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buzz/Desktop/dashboard/resources/views/dashboard/dashboard/index.blade.php ENDPATH**/ ?>