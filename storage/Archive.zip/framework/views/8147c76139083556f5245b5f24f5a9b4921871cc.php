<div class="menu-backdrop fade"></div>
<!-- /menu backdrop -->

<!--Load JQuery-->
<script src="<?php echo e(url('design/admin/node_modules/jquery/dist/jquery.min.js')); ?>"></script>
<!--Bootstrap JQuery-->
<script src="<?php echo e(url('design/admin/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<!--Perfect Scrollbar JQuery-->
<script src="<?php echo e(url('design/admin/node_modules/perfect-scrollbar/dist/perfect-scrollbar.min.js')); ?>"></script>
<!--Big Slide JQuery-->
<script src="<?php echo e(url('design/admin/node_modules/bigslide/dist/bigSlide.min.js')); ?>"></script>

<!--Custom JQuery-->
<script src="<?php echo e(url('design/admin/js/functions.js')); ?>"></script>
<script defer="defer" scr="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.2/js/toastr.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<link   rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<link   rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH /Users/buzz/Desktop/dashboard/resources/views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>