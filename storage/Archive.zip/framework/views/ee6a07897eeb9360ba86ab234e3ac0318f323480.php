<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Jumbo - A fully responsive, HTML5 based admin theme">
    <meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, jQuery, web design, CSS3, sass">
    <meta name="author" content="Ahmed Abdullah">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>
        <?php echo e(settings('name_ar')); ?>

        |
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <?php echo $__env->yieldContent('styles'); ?>
    <!-- Site favicon -->
    <link rel='shortcut icon' type='image/x-icon' href='<?php echo e(url('images/site/logo.png')); ?>' />
    <!-- /site favicon -->

    <!-- Font Material stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('design/admin/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css')); ?>">
    <!-- /font material stylesheet -->

    <!-- Bootstrap stylesheet -->
    <link href="<?php echo e(url('design/admin/css/jumbo-bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- /bootstrap stylesheet -->

    <!-- Perfect Scrollbar stylesheet -->
    <link href="<?php echo e(url('design/admin/node_modules/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
    <!-- /perfect scrollbar stylesheet -->

    <!-- Jumbo-core stylesheet -->
    <link href="<?php echo e(url('design/admin/css/jumbo-core.min.css')); ?>" rel="stylesheet">
    <!-- /jumbo-core stylesheet -->

</head>

<body id="body" data-theme="dark-indigo">
    <!-- Loader Backdrop -->
<div class="loader-backdrop">
    <!-- Loader -->
    <div class="loader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"></circle>
        </svg>
    </div>
    <!-- /loader-->
</div>
<!-- loader backdrop --><?php /**PATH /Users/buzz/Desktop/dashboard/resources/views/dashboard/layouts/header.blade.php ENDPATH**/ ?>