<div class="page-heading d-sm-flex justify-content-sm-between align-items-sm-center">
    <h2 class="title mb-3 mb-sm-0">Starter Template</h2>
    <nav class="mb-0 breadcrumb">
        <a href="index.html" class="breadcrumb-item">Jumbo</a>
        <a href="index.html" class="breadcrumb-item">Starter</a>
        <span class="active breadcrumb-item">Default</span>
    </nav>
</div><?php /**PATH /Users/buzz/Desktop/dashboard/resources/views/dashboard/layouts/breadcrumb.blade.php ENDPATH**/ ?>