<div id="menu" class="side-nav gx-sidebar">
    <div class="navbar-expand-lg">
        <!-- Sidebar header  -->
        <div class="sidebar-header">
            <div class="user-profile">
                <img class="user-avatar" alt="Domnic" src="<?php echo e(appPath()); ?>/images/users/<?php echo e(auth()->user()->avatar); ?>">

                <div class="user-detail">
                    <h4 class="user-name">
                        <span class="dropdown">
                            <a class="dropdown-toggle" href="#" role="button" id="userAccount"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                               <?php echo e(auth()->user()->name); ?>

                            </a>

                            <span class="dropdown-menu dropdown-menu-right" aria-labelledby="userAccount">
                                <a class="dropdown-item" href="javascript:void(0)">
                                    <i class="zmdi zmdi-account zmdi-hc-fw mr-2"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="javascript:void(0)">
                                    <i class="zmdi zmdi-settings zmdi-hc-fw mr-2"></i>
                                    Setting
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                    <i class="zmdi zmdi-sign-in zmdi-hc-fw mr-2"></i>
                                    Logout
                                </a>
                            </span>
                        </span>
                    </h4>
                </div>
            </div>
        </div>
        <!-- /sidebar header -->

        <!-- Main navigation -->
        <div id="main-menu" class="main-menu navbar-collapse collapse">
            <ul class="nav-menu">
                <li class="nav-header"><span class="nav-text">Main</span></li>
                <li class="menu">
                    <a href="javascript:void(0)">
                        <i class="zmdi zmdi-view-dashboard zmdi-hc-fw"></i>
                        <span class="nav-text">Starter</span>
                    </a>
                    <ul class="sub-menu">
                        <li><a href="index.html"><span class="nav-text">Default</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- /main navigation -->
    </div>
</div>
<?php /**PATH /Users/buzz/Desktop/dashboard/resources/views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>