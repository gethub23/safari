 <!-- Main Header -->
 <header class="main-header">
    <div class="gx-toolbar">
        <div class="sidebar-mobile-menu d-block d-lg-none">
            <a class="gx-menu-icon menu-toggle" href="#menu">
                <span class="menu-icon"></span>
            </a>
        </div>

        <a class="site-logo" href="<?php echo e(url('/admin')); ?>">
            <img src="<?php echo e(url('images/site/logo.png')); ?>" alt="Jumbo" title="Jumbo">
        </a>


        <ul class="quick-menu header-notifications ml-auto">

            <li class="nav-searchbox dropdown d-inline-block d-sm-none">
                <a href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true"
                   class="d-inline-block icon-btn" aria-expanded="false">
                    <i class="zmdi zmdi-search zmdi-hc-fw"></i>
                </a>
                <div aria-hidden="true"
                     class="p-0 dropdown-menu dropdown-menu-right search-bar right-side-icon search-dropdown">
                    <div class="form-group">
                        <input class="form-control border-0" placeholder="" value="" type="search">
                        <button class="search-icon"><i class="zmdi zmdi-search zmdi-hc-lg"></i></button>
                    </div>
                </div>

            </li>

            <li class="dropdown">
                <a href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" class="d-inline-block"
                   aria-expanded="true">
                    <i class="zmdi zmdi-notifications-active icons-alert animated infinite wobble"></i>
                </a>

                <div role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                    <div class="gx-card-header d-flex align-items-center">
                        <div class="mr-auto">
                            <h3 class="card-heading">Notifications</h3>
                        </div>
                    </div>

                    <div class="dropdown-menu-perfectscrollbar d-flex align-items-center justify-content-center">
                        No new messages as of now!
                    </div>
                </div>
            </li>

            <li class="dropdown">
                <a href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" class="d-inline-block"
                   aria-expanded="true">
                    <i class="zmdi zmdi-comment-alt-text icons-alert zmdi-hc-fw"></i>
                </a>

                <div class="dropdown-menu dropdown-menu-right" data-placement="bottom-end"
                     data-x-out-of-boundaries="">
                    <div class="gx-card-header d-flex align-items-center">
                        <div class="mr-auto">
                            <h3 class="card-heading">Messages</h3>
                        </div>
                    </div>

                    <div class="dropdown-menu-perfectscrollbar1 d-flex align-items-center justify-content-center">
                        No notifications as of now!
                    </div>
                </div>
            </li>
        </ul>
    </div>
</header>
<!-- /main header --><?php /**PATH /Users/buzz/Desktop/dashboard/resources/views/dashboard/layouts/headerNav.blade.php ENDPATH**/ ?>